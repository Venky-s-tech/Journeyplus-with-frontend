package com.journeyplus.trip.controller;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.journeyplus.iam.entity.User;
import com.journeyplus.iam.repository.UserRepository;
import com.journeyplus.trip.dto.ItineraryLegInput;
import com.journeyplus.trip.dto.ItineraryLegResponse;
import com.journeyplus.trip.dto.SimpleUserDTO;
import com.journeyplus.trip.dto.TripCreationRequest;
import com.journeyplus.trip.dto.TripRequestInput;
import com.journeyplus.trip.dto.TripResponse;
import com.journeyplus.trip.dto.TripSummaryResponse;
import com.journeyplus.trip.dto.VisaRequirementInput;
import com.journeyplus.trip.dto.VisaRequirementResponse;
import com.journeyplus.trip.entity.ItineraryLeg;
import com.journeyplus.trip.entity.TripRequest;
import com.journeyplus.trip.entity.TripStatus;
import com.journeyplus.trip.entity.VisaRequirement;
import com.journeyplus.trip.repository.ItineraryLegRepository;
import com.journeyplus.trip.repository.VisaRequirementRepository;
import com.journeyplus.trip.service.TripService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/trips")
public class TripRequestController {

    @Autowired
    private TripService tripService;

    @Autowired
    private UserRepository userRepository;

    // ✅ CREATE TRIP (ONLY BASIC INPUT)
    @PostMapping
    @PreAuthorize("hasRole('EMPLOYEE')")
    public ResponseEntity<TripResponse> createTrip(
            @Valid @RequestBody TripRequestInput input,
            @AuthenticationPrincipal User employee) {

        TripRequest trip = new TripRequest();
        trip.setPurpose(input.getPurpose());
        trip.setDestination(input.getDestination());
        trip.setDepartureDate(input.getDepartureDate());
        trip.setReturnDate(input.getReturnDate());
        trip.setComments(input.getComments());

        if (input.getApproverUsername() != null) {
            User mgr = userRepository.findByUsername(input.getApproverUsername())
                    .orElseThrow(() -> new IllegalArgumentException("Manager not found"));
            trip.setApprover(mgr);
        }

        trip.setEmployee(employee);

        TripRequest saved = tripService.createTripRequest(trip);

        return ResponseEntity.ok(toTripResponse(saved));
    }

    // ✅ SUBMIT
    @PostMapping("/{id}/submit")
    @PreAuthorize("hasRole('EMPLOYEE')")
    public ResponseEntity<TripResponse> submit(@PathVariable Long id,
                                               @AuthenticationPrincipal User user) {
        TripRequest saved = tripService.submitTripRequest(id, user);
        return ResponseEntity.ok(toTripResponse(saved));
    }

    // ✅ APPROVE
    @PostMapping("/{id}/approve")
    @PreAuthorize("hasRole('APPROVING_MANAGER')")
    public ResponseEntity<TripResponse> approve(@PathVariable Long id,
                                                @AuthenticationPrincipal User manager) {
        return ResponseEntity.ok(
                toTripResponse(tripService.approveTrip(id, manager))
        );
    }

    // ✅ REJECT
    @PostMapping("/{id}/reject")
    @PreAuthorize("hasRole('APPROVING_MANAGER')")
    public ResponseEntity<TripResponse> reject(@PathVariable Long id,
                                               @AuthenticationPrincipal User manager) {
        return ResponseEntity.ok(
                toTripResponse(tripService.rejectTrip(id, manager))
        );
    }

    // ✅ GET
    @GetMapping("/{id}")
    public ResponseEntity<TripResponse> getTrip(@PathVariable Long id) {
        return ResponseEntity.ok(
                toTripResponse(tripService.getTripRequest(id))
        );
    }

    // ✅ DTO MAPPER
    private TripResponse toTripResponse(TripRequest t) {
        TripResponse r = new TripResponse();
        r.setId(t.getId());
        r.setPurpose(t.getPurpose());
        r.setDestination(t.getDestination());
        r.setDepartureDate(t.getDepartureDate());
        r.setReturnDate(t.getReturnDate());
        r.setTravelType(t.getTravelType());
        r.setEstimatedCost(t.getEstimatedCost());
        r.setStatus(t.getStatus().name());
        return r;
    }
}